# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated

admin:$1$cce258b2$U9o5nK0z4MhTfB5QlKF23/:admin:admin@example.org:admin,user
