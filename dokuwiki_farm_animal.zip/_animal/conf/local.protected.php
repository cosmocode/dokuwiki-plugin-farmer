<?php
/**
 * These settings are "protected" and cannot be overwritten
 * by the configuration manager, but need to be edited manually.
 */

$conf['savedir'] = DOKU_CONF.'../data';
$conf['updatecheck'] = 0;
// if you're using the .htaccess base setup, set this to your animal's base directory:
//$conf['basedir'] = '/farm/animal/';
